const body = document.body;
const btnTema = document.querySelector('#btn-tema');

// Temas

function toggleClasses(elements, className, add) {
    elements.forEach(el => el.classList.toggle(className, add));
}

function applyTheme(isDarkTheme) {
    body.classList.toggle('bg-light', !isDarkTheme);
    body.classList.toggle('bg-black', isDarkTheme);
    document.querySelector('#drop-items').setAttribute(
        'data-bs-theme',
        isDarkTheme ? 'dark' : 'default'
    );

    const elementsToToggle = [
        ...document.querySelectorAll('p, h2, h3'),
        ...document.querySelectorAll('.card.border.border-success')
    ];

    toggleClasses(elementsToToggle, 'text-white', isDarkTheme);
    toggleClasses(
        document.querySelectorAll('.card.border.border-success'),
        'bg-dark',
        isDarkTheme
    );
}

function changeTheme() {
    const isDarkTheme = body.classList.contains('bg-light');
    applyTheme(isDarkTheme);
    localStorage.setItem('theme', isDarkTheme ? 'dark' : 'light');
}

document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    applyTheme(savedTheme === 'dark');
});

btnTema.addEventListener('click', changeTheme);